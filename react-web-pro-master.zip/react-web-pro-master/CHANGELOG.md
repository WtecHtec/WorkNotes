#
## V2.0.0
`2020-12-12`

   * 升级项目中全部依赖库版本，主要包括：react17、antd4、webpack5...
   * 增加 commitlint 规范git提交;
   * 增加 husky + lint-staged + Prettier 规范代码提交校验
   * 优化 eslint + prettier 规范项目代码风格


## V1.0.0
  第一版
