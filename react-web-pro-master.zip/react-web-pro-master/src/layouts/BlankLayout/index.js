import React from 'react';

const BlankLayout = ({ children }) => <>{children}</>;

export default BlankLayout;
