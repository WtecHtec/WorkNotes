import React from 'react';
import { Layout } from 'antd';

const MainFooter = () => <Layout.Footer>底部</Layout.Footer>;

export default MainFooter;
