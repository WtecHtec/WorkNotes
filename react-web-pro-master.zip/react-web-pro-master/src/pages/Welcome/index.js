import React from 'react';

import './style.less';

const WelcomePage = () => <div className="page-welcome" />;

export default WelcomePage;
