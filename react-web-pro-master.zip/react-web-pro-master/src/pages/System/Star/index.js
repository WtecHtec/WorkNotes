import React from 'react';

export default () => <div>Star</div>;
