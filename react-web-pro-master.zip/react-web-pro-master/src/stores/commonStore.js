import { observable } from 'mobx';

export default class CommonStore {
  @observable loading = false;
}
