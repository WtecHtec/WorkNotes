let g_noteStatus = false
let g_fabric_canvas = null
let g_loadingel = null
const g_unactives = ['close', 'save', 'other']
let g_select_status = false
let g_login = false
let g_account = ''
