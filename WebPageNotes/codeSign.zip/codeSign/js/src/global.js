let g_fabric_canvas = null;
let g_making = false;
let g_select_status = false;
let g_form_data_map = {};
let g_form_style_editor = null;
let g_form_after_editor = null;