function initRenderOpt() {
	renderOptDom();
	initOptEvent();
}