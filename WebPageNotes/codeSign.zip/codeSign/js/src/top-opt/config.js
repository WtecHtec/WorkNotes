const OPT_DATAS = [
  {
    id: 'wtc_make',
    className: 'wtechtec-opt-item',
    label: '开始制作',
  },
  {
    id: 'wtc_select',
    className: 'wtechtec-opt-item',
    label: '选择'
  },
  {
    id: 'wtc_save',
    className: 'wtechtec-opt-item',
    label: '生成'
  },
]