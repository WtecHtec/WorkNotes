const DRAW_DATA = {
	arrow: creatArrow,
	rect: drawRect,
}