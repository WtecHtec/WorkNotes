function initForm() {
  initFormDom();
  initFormEvent();
}